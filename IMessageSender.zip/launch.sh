#!/bin/bash

cd ~/Desktop

cd IMessageSender || exit

python3 app.py
